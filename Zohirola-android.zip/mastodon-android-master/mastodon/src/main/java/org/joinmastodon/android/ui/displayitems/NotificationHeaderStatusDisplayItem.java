package org.joinmastodon.android.ui.displayitems;

import android.app.Activity;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.text.style.TypefaceSpan;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import org.joinmastodon.android.GlobalUserPreferences;
import org.joinmastodon.android.R;
import org.joinmastodon.android.api.session.AccountSessionManager;
import org.joinmastodon.android.fragments.profile.ProfileFragment;
import org.joinmastodon.android.model.Account;
import org.joinmastodon.android.model.Mention;
import org.joinmastodon.android.model.NotificationType;
import org.joinmastodon.android.model.viewmodel.NotificationViewModel;
import org.joinmastodon.android.ui.OutlineProviders;
import org.joinmastodon.android.ui.text.HtmlParser;
import org.joinmastodon.android.ui.text.LinkSpan;
import org.joinmastodon.android.ui.text.NonColoredLinkSpan;
import org.joinmastodon.android.ui.utils.CustomEmojiHelper;
import org.joinmastodon.android.ui.utils.UiUtils;
import org.parceler.Parcels;

import java.util.List;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import me.grishka.appkit.Nav;
import me.grishka.appkit.imageloader.ImageLoaderViewHolder;
import me.grishka.appkit.imageloader.requests.ImageLoaderRequest;
import me.grishka.appkit.imageloader.requests.UrlImageLoaderRequest;
import me.grishka.appkit.utils.V;

public class NotificationHeaderStatusDisplayItem extends StatusDisplayItem{
	public final NotificationViewModel notification;
	private String accountID;
	private CustomEmojiHelper emojiHelper=new CustomEmojiHelper();
	private CharSequence text;
	private List<Account> accounts;
	private List<ImageLoaderRequest> avaRequests;

	public NotificationHeaderStatusDisplayItem(String parentID, Callbacks callbacks, Context context, NotificationViewModel notification, String accountID){
		super(parentID, callbacks, context);
		this.notification=notification;
		this.accountID=accountID;

		if(notification.accounts.size()<=6){
			accounts=notification.accounts;
		}else{
			accounts=notification.accounts.subList(0, 6);
		}
		avaRequests=accounts.stream()
				.map(a->new UrlImageLoaderRequest(GlobalUserPreferences.playGifs ? a.avatar : a.avatarStatic, V.dp(50), V.dp(50)))
				.collect(Collectors.toList());

		if(notification.notification.type==NotificationType.POLL && AccountSessionManager.getInstance().isSelf(accountID, notification.accounts.get(0))){
			text=context.getString(R.string.own_poll_ended);
		}else{
			Account account=notification.accounts.get(0);
			SpannableStringBuilder parsedName=new SpannableStringBuilder(account.displayName);
			if(GlobalUserPreferences.customEmojiInNames)
				HtmlParser.parseCustomEmoji(parsedName, account.emojis);
			emojiHelper.setText(parsedName);

			String text;
			if(accounts.size()>1 && notification.notification.type.canBeGrouped()){
				text=context.getResources().getQuantityString(switch(notification.notification.type){
					case FAVORITE -> R.plurals.user_and_x_more_favorited;
					case REBLOG -> R.plurals.user_and_x_more_boosted;
					case FOLLOW -> R.plurals.user_and_x_more_followed;
					default -> throw new IllegalStateException("Unexpected value: " + notification.notification.type);
				}, notification.notification.notificationsCount-1, "{{name}}", notification.notification.notificationsCount-1);
			}else if(notification.notification.type==NotificationType.POLL){
				if(notification.status==null || notification.status.poll==null){
					text="???";
				}else{
					int count=notification.status.poll.votersCount-1;
					text=context.getResources().getQuantityString(R.plurals.poll_ended_x_voters, count, "{{name}}", count);
				}
			}else if(notification.notification.type==NotificationType.FALLBACK){
				text=null;
				List<Mention> fakeMentions=notification.accounts.stream().map(Mention::new).collect(Collectors.toList());
				SpannableStringBuilder parsedText=HtmlParser.parse(notification.notification.fallback.title, List.of(), fakeMentions, List.of(), accountID, notification, context);
				LinkSpan[] links=parsedText.getSpans(0, parsedText.length(), LinkSpan.class);
				for(LinkSpan ls:links){
					int start=parsedText.getSpanStart(ls);
					int end=parsedText.getSpanEnd(ls);
					parsedText.removeSpan(ls);
					parsedText.setSpan(new NonColoredLinkSpan(ls), start, end, 0);
					parsedText.setSpan(new TypefaceSpan("sans-serif-medium"), start, end, 0);
				}
				this.text=parsedText;
			}else if(notification.notification.type==NotificationType.ADMIN_REPORT){
				text=null;
				String t=context.getString(R.string.notification_admin_report, "{{name}}", "{{target}}");
				SpannableStringBuilder ssb=new SpannableStringBuilder(t);
				int nameOffset=t.indexOf("{{name}}");
				if(nameOffset!=-1){
					ssb.replace(nameOffset, nameOffset+"{{name}}".length(), parsedName);
					ssb.setSpan(new TypefaceSpan("sans-serif-medium"), nameOffset, nameOffset+parsedName.length(), 0);
				}
				int targetOffset=ssb.toString().indexOf("{{target}}");
				if(targetOffset!=-1){
					CharSequence name=GlobalUserPreferences.customEmojiInNames ? HtmlParser.parseCustomEmoji(notification.notification.report.targetAccount.displayName,
							notification.notification.report.targetAccount.emojis) : notification.notification.report.targetAccount.displayName;
					ssb.replace(targetOffset, targetOffset+"{{target}}".length(), name);
					ssb.setSpan(new TypefaceSpan("sans-serif-medium"), targetOffset, targetOffset+name.length(), 0);
				}
				this.text=ssb;
				emojiHelper.setText(ssb);
			}else{
				text=context.getString(switch(notification.notification.type){
					case FOLLOW -> R.string.user_followed_you;
					case FOLLOW_REQUEST -> R.string.user_sent_follow_request;
					case REBLOG -> R.string.notification_boosted;
					case FAVORITE -> R.string.user_favorited;
					case UPDATE -> R.string.user_edited_post;
					case QUOTED_UPDATE -> R.string.user_edited_quoted_post;
					case ADMIN_SIGNUP -> R.string.notification_admin_signup;
					case ADDED_TO_COLLECTION -> R.string.notification_added_you_to_collection;
					case COLLECTION_UPDATE -> R.string.notification_collection_edited;
					default -> throw new IllegalStateException("Unexpected value: "+notification.notification.type);
				}, "{{name}}");
			}
			if(notification.notification.type!=NotificationType.FALLBACK && notification.notification.type!=NotificationType.ADMIN_REPORT){
				String[] parts=text.split(Pattern.quote("{{name}}"), 2);
				SpannableStringBuilder formattedText=new SpannableStringBuilder();
				if(parts.length>1 && !TextUtils.isEmpty(parts[0]))
					formattedText.append(parts[0]);
				formattedText.append(parsedName, new TypefaceSpan("sans-serif-medium"), 0);
				formattedText.setSpan(new NonColoredLinkSpan(null, s->{
					Bundle args=new Bundle();
					args.putString("account", accountID);
					args.putParcelable("profileAccount", Parcels.wrap(account));
					Nav.go((Activity) context, ProfileFragment.class, args);
				}, LinkSpan.Type.CUSTOM, null, null, null), formattedText.length()-parsedName.length(), formattedText.length(), 0);
				if(parts.length==1){
					formattedText.append(' ');
					formattedText.append(parts[0]);
				}else if(!TextUtils.isEmpty(parts[1])){
					formattedText.append(parts[1]);
				}
				this.text=formattedText;
			}
		}
	}

	@Override
	public Type getType(){
		return Type.NOTIFICATION_HEADER;
	}

	@Override
	public int getImageCount(){
		return avaRequests.size()+emojiHelper.getImageCount();
	}

	@Override
	public ImageLoaderRequest getImageRequest(int index){
		if(index>=avaRequests.size()){
			return emojiHelper.getImageRequest(index-avaRequests.size());
		}
		return avaRequests.get(index);
	}

	private boolean shouldHaveBottomPadding(){
		return notification.status==null && !(notification.notification.type==NotificationType.FALLBACK && !TextUtils.isEmpty(notification.notification.fallback.summary))
				&& !(notification.notification.type==NotificationType.ADMIN_REPORT && !TextUtils.isEmpty(notification.notification.report.comment))
				&& !(notification.notification.type==NotificationType.ADDED_TO_COLLECTION || notification.notification.type==NotificationType.COLLECTION_UPDATE);
	}

	public static class Holder extends StatusDisplayItem.Holder<NotificationHeaderStatusDisplayItem> implements ImageLoaderViewHolder{
		private final ImageView icon;
		private final TextView text;
		private final ImageView[] avatars;
		private final View avatarsContainer;

		public Holder(Activity activity, ViewGroup parent){
			super(activity, R.layout.display_item_notification_header, parent);
			icon=findViewById(R.id.icon);
			text=findViewById(R.id.text);
			avatars=new ImageView[]{
					findViewById(R.id.avatar1),
					findViewById(R.id.avatar2),
					findViewById(R.id.avatar3),
					findViewById(R.id.avatar4),
					findViewById(R.id.avatar5),
					findViewById(R.id.avatar6),
			};
			avatarsContainer=findViewById(R.id.avatars);

			int i=0;
			for(ImageView avatar:avatars){
				avatar.setOutlineProvider(OutlineProviders.roundedRect(6));
				avatar.setClipToOutline(true);
				avatar.setOnClickListener(this::onAvaClick);
				avatar.setTag(i);
				i++;
			}
		}

		@Override
		public void setImage(int index, Drawable image){
			if(index<item.avaRequests.size()){
				avatars[index].setImageDrawable(image);
			}else{
				item.emojiHelper.setImageDrawable(index-item.avaRequests.size(), image);
				text.invalidate();
			}
		}

		@Override
		public void clearImage(int index){
			if(index<item.avaRequests.size())
				avatars[index].setImageResource(R.drawable.image_placeholder);
			else
				ImageLoaderViewHolder.super.clearImage(index);
		}

		@Override
		public void onBind(NotificationHeaderStatusDisplayItem item){
			text.setText(item.text);

			if(item.notification.notification.type==NotificationType.POLL || item.notification.notification.type==NotificationType.UPDATE || item.notification.accounts.isEmpty()){
				avatarsContainer.setVisibility(View.GONE);
			}else{
				avatarsContainer.setVisibility(View.VISIBLE);
				for(int i=0;i<avatars.length;i++){
					if(i>=item.accounts.size()){
						avatars[i].setVisibility(View.GONE);
					}else{
						avatars[i].setVisibility(View.VISIBLE);
						avatars[i].setContentDescription(item.context.getString(R.string.avatar_description, item.notification.accounts.get(i).acct));
					}
				}
			}
			icon.setImageResource(switch(item.notification.notification.type){
				case FAVORITE -> R.drawable.ic_star_fill1_24px;
				case REBLOG -> R.drawable.ic_repeat_fill1_24px;
				case FOLLOW, FOLLOW_REQUEST, ADMIN_SIGNUP -> R.drawable.ic_person_add_fill1_24px;
				case POLL -> R.drawable.ic_insert_chart_fill1_24px;
				case UPDATE, QUOTED_UPDATE -> R.drawable.ic_edit_24px;
				case FALLBACK -> R.drawable.ic_notification_fallback;
				case ADMIN_REPORT -> R.drawable.ic_flag_fill1_24px;
				case ADDED_TO_COLLECTION, COLLECTION_UPDATE -> R.drawable.ic_category_fill1_24px;
				default -> throw new IllegalStateException("Unexpected value: "+item.notification.notification.type);
			});
			icon.setImageTintList(ColorStateList.valueOf(UiUtils.getThemeColor(item.context, switch(item.notification.notification.type){
				case FAVORITE -> R.attr.colorFavorite;
				case REBLOG -> R.attr.colorBoost;
				case FOLLOW, FOLLOW_REQUEST, UPDATE -> R.attr.colorM3Primary;
				case FALLBACK -> R.attr.colorBrand;
				default -> R.attr.colorM3Outline;
			})));
			itemView.setPadding(itemView.getPaddingLeft(), itemView.getPaddingTop(), itemView.getPaddingRight(), item.shouldHaveBottomPadding() ? V.dp(12) : 0);
		}

		private void onAvaClick(View v){
			Bundle args=new Bundle();
			args.putString("account", item.accountID);
			args.putParcelable("profileAccount", Parcels.wrap(item.notification.accounts.get((Integer)v.getTag())));
			Nav.go((Activity) item.context, ProfileFragment.class, args);
		}
	}
}
